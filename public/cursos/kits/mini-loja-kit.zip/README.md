# mini-loja

Projeto Django de exemplo das aulas de Fundamentos (instalar, primeiro projeto e primeira API). Tem produtos, pedidos com *snapshot* de preço e uma compra com baixa condicional de estoque.

```powershell
py -3.12 -m venv .venv
.venv\Scripts\python -m pip install -r requirements.txt
.venv\Scripts\python manage.py migrate
.venv\Scripts\python manage.py test          # 7 testes
.venv\Scripts\python manage.py runserver     # http://127.0.0.1:8000/api/
```

**Testado em 13/11/2026** (Windows 11): Python 3.12.10, Django 5.1.4, Django REST Framework 3.15.2.

- 7 testes passam.
- Com o servidor rodando, `GET /api/produtos/` devolveu 200; uma compra de 2 unidades devolveu 201 e baixou o estoque de 3 para 1; uma compra de 9 devolveu 409 ("Estoque insuficiente.").
- A chave `SECRET_KEY` do exemplo é só de desenvolvimento. Em produção ela vem de variável de ambiente.
- O teste de corrida com várias threads **não** está aqui de propósito: o SQLite não aceita bem escritores simultâneos. Teste de concorrência de verdade precisa de PostgreSQL (aula 4 do módulo principal).
