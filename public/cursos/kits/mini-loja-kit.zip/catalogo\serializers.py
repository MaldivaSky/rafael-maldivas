from rest_framework import serializers

from .models import ItemPedido, Pedido, Produto


class ProdutoSerializer(serializers.ModelSerializer):
    class Meta:
        model = Produto
        fields = ["id", "nome", "preco", "estoque"]


class ItemPedidoSerializer(serializers.ModelSerializer):
    class Meta:
        model = ItemPedido
        fields = ["nome", "preco_unitario", "quantidade"]


class PedidoSerializer(serializers.ModelSerializer):
    itens = ItemPedidoSerializer(many=True, read_only=True)

    class Meta:
        model = Pedido
        fields = ["id", "cliente", "status", "criado_em", "itens"]
        read_only_fields = ["status"]          # o cliente NÃO escolhe o status
