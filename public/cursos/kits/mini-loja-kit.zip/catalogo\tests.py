from decimal import Decimal

from django.test import TestCase
from rest_framework.test import APIClient

from .models import ItemPedido, Pedido, Produto


class ProdutoApiTests(TestCase):
    def setUp(self):
        self.api = APIClient()
        self.bolsa = Produto.objects.create(nome="Bolsa de macramê", preco=Decimal("89.00"), estoque=3)

    def test_lista_os_produtos(self):
        resposta = self.api.get("/api/produtos/")
        self.assertEqual(resposta.status_code, 200)
        self.assertEqual(resposta.json()[0]["nome"], "Bolsa de macramê")

    def test_compra_baixa_o_estoque_e_cria_o_pedido(self):
        resposta = self.api.post(f"/api/produtos/{self.bolsa.pk}/comprar/", {"cliente": "Ana", "quantidade": 2}, format="json")
        self.assertEqual(resposta.status_code, 201)
        self.bolsa.refresh_from_db()
        self.assertEqual(self.bolsa.estoque, 1)
        self.assertEqual(Pedido.objects.count(), 1)

    def test_compra_acima_do_estoque_e_recusada_e_nao_deixa_pedido(self):
        resposta = self.api.post(f"/api/produtos/{self.bolsa.pk}/comprar/", {"cliente": "Ana", "quantidade": 9}, format="json")
        self.assertEqual(resposta.status_code, 409)
        self.bolsa.refresh_from_db()
        self.assertEqual(self.bolsa.estoque, 3)
        self.assertEqual(Pedido.objects.count(), 0)

    def test_dados_invalidos_voltam_400(self):
        for corpo in ({"quantidade": 1}, {"cliente": "Ana", "quantidade": 0}, {"cliente": "Ana", "quantidade": "x"}):
            resposta = self.api.post(f"/api/produtos/{self.bolsa.pk}/comprar/", corpo, format="json")
            self.assertEqual(resposta.status_code, 400, corpo)

    def test_o_item_guarda_o_preco_do_momento_da_compra(self):
        self.api.post(f"/api/produtos/{self.bolsa.pk}/comprar/", {"cliente": "Ana"}, format="json")
        self.bolsa.preco = Decimal("120.00")
        self.bolsa.save()
        item = ItemPedido.objects.get()
        self.assertEqual(item.preco_unitario, Decimal("89.00"))      # snapshot: não mudou

    def test_cliente_nao_consegue_escolher_o_status_do_pedido(self):
        pedido = Pedido.objects.create(cliente="Ana")
        resposta = self.api.post("/api/pedidos/", {"cliente": "Bia", "status": "confirmado"}, format="json")
        self.assertEqual(resposta.status_code, 405)                  # pedidos são só leitura
        self.assertEqual(Pedido.objects.get(pk=pedido.pk).status, Pedido.Status.PENDENTE)


class PecaUnicaTests(TestCase):
    """A última peça só pode ser vendida uma vez (a segunda compra recebe 409)."""

    def test_ultima_peca_vende_uma_vez(self):
        produto = Produto.objects.create(nome="Peça única", preco=Decimal("100.00"), estoque=1)
        api = APIClient()
        primeira = api.post(f"/api/produtos/{produto.pk}/comprar/", {"cliente": "Ana"}, format="json")
        segunda = api.post(f"/api/produtos/{produto.pk}/comprar/", {"cliente": "Bia"}, format="json")
        self.assertEqual((primeira.status_code, segunda.status_code), (201, 409))
        produto.refresh_from_db()
        self.assertEqual(produto.estoque, 0)
        self.assertEqual(Pedido.objects.count(), 1)       # a segunda compra não deixou pedido
