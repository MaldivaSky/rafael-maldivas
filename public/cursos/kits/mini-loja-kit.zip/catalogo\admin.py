from django.contrib import admin

from .models import ItemPedido, Pedido, Produto

admin.site.register(Produto)
admin.site.register(Pedido)
admin.site.register(ItemPedido)
