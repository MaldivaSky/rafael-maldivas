from django.db import transaction
from django.db.models import F
from rest_framework import status, viewsets
from rest_framework.decorators import action
from rest_framework.response import Response

from .models import ItemPedido, Pedido, Produto
from .serializers import PedidoSerializer, ProdutoSerializer


class ProdutoViewSet(viewsets.ModelViewSet):
    """Lista, cria, detalha, edita e apaga produtos: /api/produtos/"""

    queryset = Produto.objects.all().order_by("id")
    serializer_class = ProdutoSerializer

    @action(detail=True, methods=["post"])
    def comprar(self, request, pk=None):
        """POST /api/produtos/<id>/comprar/   corpo: {"cliente": "Ana", "quantidade": 1}"""
        cliente = str(request.data.get("cliente", "")).strip()
        try:
            quantidade = int(request.data.get("quantidade", 1))
        except (TypeError, ValueError):
            quantidade = 0
        if not cliente or quantidade < 1:
            return Response({"detail": "Informe o cliente e uma quantidade maior que zero."},
                            status=status.HTTP_400_BAD_REQUEST)

        produto = self.get_object()
        with transaction.atomic():
            # Baixa condicional: a verificação e a subtração acontecem juntas, dentro do banco.
            baixou = (Produto.objects.filter(pk=produto.pk, estoque__gte=quantidade)
                      .update(estoque=F("estoque") - quantidade))
            if not baixou:
                return Response({"detail": "Estoque insuficiente."}, status=status.HTTP_409_CONFLICT)
            produto.refresh_from_db()
            pedido = Pedido.objects.create(cliente=cliente)
            ItemPedido.objects.create(pedido=pedido, produto=produto, nome=produto.nome,
                                      preco_unitario=produto.preco, quantidade=quantidade)
        return Response(PedidoSerializer(pedido).data, status=status.HTTP_201_CREATED)


class PedidoViewSet(viewsets.ReadOnlyModelViewSet):
    """Só leitura: pedidos nascem pela compra, nunca por um POST direto."""

    queryset = Pedido.objects.prefetch_related("itens").order_by("-id")
    serializer_class = PedidoSerializer
