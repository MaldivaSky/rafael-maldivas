from django.urls import include, path
from rest_framework.routers import DefaultRouter

from .views import PedidoViewSet, ProdutoViewSet

router = DefaultRouter()
router.register("produtos", ProdutoViewSet)
router.register("pedidos", PedidoViewSet)

urlpatterns = [path("", include(router.urls))]
