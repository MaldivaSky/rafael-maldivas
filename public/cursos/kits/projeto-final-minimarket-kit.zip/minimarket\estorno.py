﻿from decimal import Decimal

class ErroEstorno(Exception):
    pass

class Pagamento:
    def __init__(self, txid, valor):
        self.txid = txid
        self.valor = Decimal(str(valor))
        self.estornado = Decimal("0")
        self.status = "approved"

class ProvedorFalso:
    def __init__(self):
        self.total_devolvido = Decimal("0")
        self.falhar_depois_de_processar = False
        self._chaves = set()

def estornar(pagamento, provedor, valor):
    """Executa estorno com ID deterministico, checagem de teto acumulado e registro apenas apos o provedor."""
    raise NotImplementedError("Implemente estornar seguindo a Aula A07.")
