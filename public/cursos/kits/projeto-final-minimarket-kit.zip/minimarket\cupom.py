﻿from decimal import Decimal

def ratear_desconto(desconto, subtotais):
    """Divide o desconto proporcionalmente entre as lojas em centavos exatos.
    A sobra de arredondamento vai na ultima loja para que sum(partes) == Decimal(desconto).
    """
    raise NotImplementedError("Implemente ratear_desconto seguindo a Aula A03.")
