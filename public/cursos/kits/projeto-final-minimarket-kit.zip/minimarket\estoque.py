﻿def preparar(db_path, estoque=1):
    raise NotImplementedError("Crie a tabela no SQLite e inicialize o estoque.")

def comprar(db_path):
    """Realiza baixa condicional atomica (UPDATE ... WHERE stock >= 1). Retorna 1 se comprou, 0 se esgotou."""
    raise NotImplementedError("Implemente comprar com baixa condicional (Aula A04).")

def disputar(fn, db_path, compradores=8):
    """Dispara N threads simultaneas chamando fn(db_path) e retorna lista de resultados."""
    raise NotImplementedError("Implemente disputar com threading.Barrier (Aula A04).")

def estoque_atual(db_path):
    raise NotImplementedError("Consulte e retorne o estoque atual no SQLite.")

def ordem_de_travas(ids):
    """Retorna lista ordenada e sem duplicatas para prevenir deadlock."""
    raise NotImplementedError("Implemente ordem_de_travas (Aula A04).")
