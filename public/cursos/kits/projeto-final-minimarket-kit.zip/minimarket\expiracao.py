﻿def expirar(pedidos, estoque, cupons):
    """Cancela pedidos pending expirados (> 60 min) sem pagamento (respeitando excecao de cartao pending),
    devolvendo itens ao estoque e 1 uso ao cupom (sem ficar negativo), de forma idempotente.
    Retorna quantidade de pedidos expirados nesta execucao.
    """
    raise NotImplementedError("Implemente expirar seguindo a Aula A08.")
