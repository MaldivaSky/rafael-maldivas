﻿def validar_webhook(segredo_configurado, segredo_recebido, eh_producao, valor_recebido, valor_pedido):
    """Defesas (Aula A06):
    - Fail-closed: segredo_configurado vazio -> (503, ...)
    - Tempo constante (hmac.compare_digest): segredo errado -> (401, ...)
    - Conferencia de valor: valor_recebido < valor_pedido -> (400, "pago a menor")
    - Tudo valido -> (200, "confirmar")
    """
    raise NotImplementedError("Implemente validar_webhook seguindo a Aula A06.")

class Pedido:
    def __init__(self, status="pending"):
        self.status = status
        self.comissoes = 0
        self.repasses = 0
        self.pagamentos_orfaos = 0

def confirmar_pagamento(pedido):
    """Confirma pagamento de forma idempotente e thread-safe.
    Se cancelled -> incrementa pagamentos_orfaos e retorna False.
    Se ja paid -> retorna False. Se pending -> muda para paid, gera 1 comissao e 1 repasse, retorna True.
    """
    raise NotImplementedError("Implemente confirmar_pagamento seguindo a Aula A06.")
