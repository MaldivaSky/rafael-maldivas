"""Testes de aceitação do PROJETO FINAL (só biblioteca padrão, Python 3.10+).

Uso (a partir da pasta `projeto/`):

    python testes_aceitacao.py caminho/para/a/pasta/que/contem/minimarket

    python testes_aceitacao.py referencia        # confere a implementação de referência (professor)

A pasta indicada deve conter o pacote `minimarket/` com os módulos e funções descritos em PROJETO-FINAL.md.
"""
import importlib
import os
import random
import sys
import tempfile
import threading
import unittest
from decimal import Decimal as D
from pathlib import Path

ALVO = Path(next((a for a in sys.argv[1:] if not a.startswith("-")), "referencia")).resolve()
sys.path.insert(0, str(ALVO))
sys.argv = [sys.argv[0]] + [a for a in sys.argv[1:] if a.startswith("-")]


def modulo(nome):
    return importlib.import_module(f"minimarket.{nome}")


class A1Dinheiro(unittest.TestCase):
    """Margem do pedido (Aula 1)."""

    def test_pix_e_cartao_de_100(self):
        d = modulo("dinheiro")
        self.assertEqual(d.calcular_pedido(100, metodo="pix")["sobra_plataforma"], D("11.01"))
        self.assertEqual(d.calcular_pedido(100, metodo="cartao")["sobra_plataforma"], D("7.62"))

    def test_conservacao_em_casos_sorteados(self):
        d, g = modulo("dinheiro"), random.Random(11)
        for _ in range(200):
            sub, desc = D(g.randint(1, 90000)) / 100, D(g.randint(0, 5000)) / 100
            fr, met = D(g.randint(0, 4000)) / 100, g.choice(["pix", "cartao"])
            r = d.calcular_pedido(sub, desc, fr, met)
            self.assertEqual(r["valor_lojista"] + r["comissao"], r["total_cliente"], (sub, desc, fr, met))


class A3Rateio(unittest.TestCase):
    def test_a_soma_fecha_com_o_desconto(self):
        c, g = modulo("cupom"), random.Random(5)
        for _ in range(200):
            subs = [D(g.randint(1, 99999)) / 100 for _ in range(g.randint(1, 6))]
            desc = D(g.randint(1, int(sum(subs) * 100))) / 100
            self.assertEqual(sum(c.ratear_desconto(desc, subs), D("0")), desc)


class A4Estoque(unittest.TestCase):
    def setUp(self):
        fd, self.db = tempfile.mkstemp(suffix=".db")
        os.close(fd)

    def tearDown(self):
        try:
            os.remove(self.db)
        except OSError:
            pass

    def test_ultima_peca_vende_uma_vez(self):
        e = modulo("estoque")
        e.preparar(self.db, estoque=1)
        resultados = e.disputar(e.comprar, self.db, compradores=8)
        self.assertEqual(sum(resultados), 1)
        self.assertEqual(e.estoque_atual(self.db), 0)

    def test_ordem_de_travas_e_fixa_e_sem_repeticao(self):
        e = modulo("estoque")
        self.assertEqual(e.ordem_de_travas(["B", "A", "B", "C"]), ["A", "B", "C"])
        self.assertEqual(e.ordem_de_travas(["A", "B"]), e.ordem_de_travas(["B", "A"]))


class A6Pagamento(unittest.TestCase):
    def test_webhook_cenarios(self):
        p = modulo("pagamento")
        self.assertEqual(p.validar_webhook("", "x", False, 100, 100)[0], 503)
        self.assertEqual(p.validar_webhook("s3", "errado", False, 100, 100)[0], 401)
        self.assertIn("a menor", p.validar_webhook("s3", "s3", False, "99.99", "100.00")[1])
        self.assertEqual(p.validar_webhook("s3", "s3", False, "100.00", "100.00"), (200, "confirmar"))

    def test_vinte_avisos_confirmam_uma_vez(self):
        p, pedido, resultados = modulo("pagamento"), None, []
        pedido = p.Pedido()
        largada = threading.Barrier(20)

        def disparar():
            largada.wait()
            resultados.append(p.confirmar_pagamento(pedido))

        ts = [threading.Thread(target=disparar) for _ in range(20)]
        [t.start() for t in ts]
        [t.join() for t in ts]
        self.assertEqual(sum(resultados), 1)
        self.assertEqual((pedido.comissoes, pedido.repasses), (1, 1))

    def test_pedido_cancelado_nao_ressuscita_e_conta_pagamento_orfao(self):
        p = modulo("pagamento")
        pedido = p.Pedido(status="cancelled")
        self.assertFalse(p.confirmar_pagamento(pedido))
        self.assertEqual((pedido.status, pedido.comissoes, pedido.pagamentos_orfaos), ("cancelled", 0, 1))


class A7Estorno(unittest.TestCase):
    def test_timeout_nao_devolve_em_dobro_e_parciais_somam(self):
        e = modulo("estorno")
        pg, prov = e.Pagamento("a" * 32, D("100.00")), e.ProvedorFalso()
        prov.falhar_depois_de_processar = True
        with self.assertRaises(e.ErroEstorno):
            e.estornar(pg, prov, 30)
        e.estornar(pg, prov, 30)
        self.assertEqual((pg.estornado, prov.total_devolvido), (D("30"), D("30")))
        e.estornar(pg, prov, 30)
        self.assertEqual((pg.estornado, prov.total_devolvido), (D("60"), D("60")))

    def test_teto(self):
        e = modulo("estorno")
        pg, prov = e.Pagamento("b" * 32, D("100.00")), e.ProvedorFalso()
        e.estornar(pg, prov, 60)
        with self.assertRaises(e.ErroEstorno):
            e.estornar(pg, prov, 50)


class A8Expiracao(unittest.TestCase):
    def test_estoque_e_cupom_voltam_uma_unica_vez(self):
        x = modulo("expiracao")
        pedidos = [
            {"status": "pending", "idade_min": 61, "pagamento": None, "itens": {"bolsa": 2}, "cupom": "PROMO"},
            {"status": "pending", "idade_min": 61, "pagamento": ("credit_card", "pending"), "itens": {"vela": 1}, "cupom": "PROMO"},
        ]
        estoque, cupons = {"bolsa": 5, "vela": 5}, {"PROMO": 3}
        self.assertEqual(x.expirar(pedidos, estoque, cupons), 1)
        self.assertEqual(x.expirar(pedidos, estoque, cupons), 0)          # idempotente
        self.assertEqual((estoque, cupons), ({"bolsa": 7, "vela": 5}, {"PROMO": 2}))

    def test_cupom_nunca_fica_negativo(self):
        x = modulo("expiracao")
        cupons = {"UNICO": 0}
        x.expirar([{"status": "pending", "idade_min": 90, "pagamento": None, "itens": {}, "cupom": "UNICO"}], {}, cupons)
        self.assertEqual(cupons["UNICO"], 0)


class IntegracaoFluxoCompleto(unittest.TestCase):
    """Um pedido de duas lojas, com cupom da plataforma, do preço ao estorno."""

    def test_fluxo(self):
        d, c, p, e = modulo("dinheiro"), modulo("cupom"), modulo("pagamento"), modulo("estorno")
        subtotais, fretes = [D("150"), D("100")], [D("15"), D("12")]
        desconto = D("50.00")
        partes = c.ratear_desconto(desconto, subtotais)
        self.assertEqual(partes, [D("30.00"), D("20.00")])

        total_cliente = D("0")
        soma_lojas_e_comissoes = D("0")
        for sub, desc_loja, fr in zip(subtotais, partes, fretes):
            r = d.calcular_pedido(sub, desc_loja, fr, "pix")
            total_cliente += r["total_cliente"]
            soma_lojas_e_comissoes += r["valor_lojista"] + r["comissao"]
        self.assertEqual(total_cliente, D("227.00"))
        self.assertEqual(soma_lojas_e_comissoes, total_cliente)            # o dinheiro fecha

        pedido = p.Pedido()
        self.assertTrue(p.confirmar_pagamento(pedido))
        self.assertFalse(p.confirmar_pagamento(pedido))
        pg, prov = e.Pagamento("c" * 32, total_cliente), e.ProvedorFalso()
        e.estornar(pg, prov, D("27.00"))
        self.assertEqual((pg.estornado, pg.status), (D("27.00"), "approved"))


if __name__ == "__main__":
    unittest.main(verbosity=2)
