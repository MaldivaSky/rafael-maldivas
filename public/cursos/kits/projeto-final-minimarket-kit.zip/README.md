﻿# Arcabouco do Projeto Final — minimarket (Maldivas Tech)

1. Descompacte esta pasta no seu computador.
2. Rode os testes de aceitacao no terminal (Python 3.10+):
   python testes_aceitacao.py .
3. No inicio, os testes vao falhar com NotImplementedError.
4. Implemente cada modulo em `minimarket/` seguindo as aulas A01 a A08 ate todos os testes passarem (`OK`).
5. Cole a saida do terminal e o link do seu repositorio na pagina do Projeto Final para avaliacao!
