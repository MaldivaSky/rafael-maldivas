﻿from decimal import Decimal

def calcular_pedido(subtotal, desconto=0, frete=0, metodo="pix"):
    """Retorna dict com: total_cliente, valor_lojista, comissao, sobra_plataforma (em Decimal).
    Regras (A01): comissao 12% sobre subtotal_efetivo (nunca sobre frete);
    arredondamento ROUND_HALF_UP para 2 casas; PIX 0,99%, Cartao 3,99% + R$ 0,39.
    """
    raise NotImplementedError("Implemente calcular_pedido seguindo a Aula A01.")
