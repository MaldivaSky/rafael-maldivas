# ============================================================================
# COMODO 2: O ALICERCE DO BANCO DE DADOS (Tijolos da Modelagem)
# Objetivo: Guardar dinheiro em centavos inteiros (nunca float!) e congelar
# o preco pago no momento da compra (snapshot).
# ============================================================================

def criar_produto(nome: str, preco_centavos: int, estoque: int) -> dict:
    # [TIJOLO 1]: Valide que preco_centavos e um inteiro positivo e estoque >= 0
    if not isinstance(preco_centavos, int) or preco_centavos <= 0:
        raise ValueError("Preco deve ser guardado em centavos inteiros positivos!")
    if estoque < 0:
        raise ValueError("Estoque inicial nao pode ser negativo!")
    return {
        "nome": nome,
        "preco_centavos": preco_centavos,
        "estoque": estoque,
    }

def criar_item_pedido_snapshot(produto: dict, quantidade: int) -> dict:
    # [TIJOLO 2]: Copie (snapshot) o nome e o preco_centavos do produto no ato da compra
    return {
        "produto_nome_snapshot": produto["nome"],
        "preco_unitario_snapshot": produto["preco_centavos"],
        "quantidade": quantidade,
        "subtotal_centavos": produto["preco_centavos"] * quantidade,
    }
