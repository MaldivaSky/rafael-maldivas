# ============================================================================
# COMODO 3: AS PAREDES E O CONFERENTE (Regras da API e Estoque Seguro)
# Objetivo: O servidor recalcula o total e impede vender mais do que o estoque.
# ============================================================================

def baixar_estoque_seguro(produto: dict, qtd_pedida: int) -> tuple[bool, str]:
    # [PAREDE 1]: Nunca deixe o estoque ficar negativo!
    if qtd_pedida <= 0:
        return False, "Quantidade invalida"
    if produto["estoque"] < qtd_pedida:
        return False, "409 Conflict: Estoque insuficiente"
    produto["estoque"] -= qtd_pedida
    return True, "201 Created: Estoque reservado com sucesso"

def calcular_split_lojista(subtotal_centavos: int, taxa_comissao_bps: int = 1200) -> dict:
    # [PAREDE 2]: 1200 bps = 12%. A soma comissao + repasse deve fechar 100% dos centavos!
    comissao = (subtotal_centavos * taxa_comissao_bps) // 10000
    repasse_lojista = subtotal_centavos - comissao
    return {
        "subtotal_centavos": subtotal_centavos,
        "comissao_plataforma_centavos": comissao,
        "repasse_lojista_centavos": repasse_lojista,
    }
