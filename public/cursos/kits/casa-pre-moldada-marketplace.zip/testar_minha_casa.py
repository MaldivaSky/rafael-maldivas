import os
import importlib.util

def carregar_modulo(caminho, nome):
    spec = importlib.util.spec_from_file_location(nome, caminho)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod

def main():
    print("=== INSPETOR DA CASA PRE-MOLDADA (MALDIVAS TECH) ===")
    vitrine = os.path.exists("01-acabamento-vitrine/index.html")
    print(f"[1/4] Acabamento & Moveis (index.html): {'OK' if vitrine else 'FALTANDO'}")

    models = carregar_modulo("02-alicerce-banco/models_esqueleto.py", "models_esqueleto")
    p = models.criar_produto("Camiseta Tech", 7990, 2)
    snap = models.criar_item_pedido_snapshot(p, 2)
    assert snap["subtotal_centavos"] == 15980, "Subtotal em centavos incorreto"
    print("[2/4] Alicerce & Snapshot em Centavos: OK (R$ 159,80 exatos)")

    api = carregar_modulo("03-paredes-api/api_esqueleto.py", "api_esqueleto")
    ok1, _ = api.baixar_estoque_seguro(p, 2)
    ok2, _ = api.baixar_estoque_seguro(p, 1)
    assert ok1 is True and ok2 is False, "Falha na trava de estoque"
    split = api.calcular_split_lojista(10000, 1200)
    assert split["comissao_plataforma_centavos"] + split["repasse_lojista_centavos"] == 10000
    print("[3/4] Paredes da API & Trava contra Venda Dupla: OK")

    gitignore_ok = os.path.exists("04-telhado-deploy/.gitignore")
    print(f"[4/4] Telhado & Protecao de Deploy (.gitignore): {'OK' if gitignore_ok else 'FALTANDO'}")
    print("\nPARABENS! Sua Casa Pre-Moldada passou em todas as inspecoes!")

if __name__ == "__main__":
    main()
