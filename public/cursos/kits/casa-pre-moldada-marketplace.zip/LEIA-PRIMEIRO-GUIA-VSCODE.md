# Casa Pré-Moldada do Seu Marketplace (Guia Passo a Passo no VS Code)

Bem-vindo! Este pacote é como uma **casa pré-moldada**: a fundação e a planta já estão desenhadas para você não começar de uma tela em branco. Você só precisa colocar os tijolos, levantar as paredes e escolher os móveis no lugar indicado!

---

## PASSO 1: Instale as 3 Ferramentas Gratuitas no seu Computador
1. **VS Code (Seu Escritório de Código)**: Baixe grátis em https://code.visualstudio.com e instale (Next -> Next -> Finish).
2. **Python 3.12 (O Motor)**: Baixe em https://www.python.org/downloads/
   - **ATENÇÃO**: Na primeira tela do instalador, marque a caixinha **[x] Add python.exe to PATH** antes de clicar em Install Now!
3. **Git (A Máquina do Tempo)**: Baixe em https://git-scm.com/downloads

---

## PASSO 2: Abra sua Casa Pré-Moldada no VS Code
1. Descompacte este arquivo `.zip` em uma pasta (ex.: `Documentos/minha-loja`).
2. Abra o **VS Code**, clique em **File -> Open Folder...** (Arquivo -> Abrir Pasta) e selecione a pasta descompactada.
3. Abra o **Terminal Integrado** dentro do próprio VS Code apertando **`Ctrl + '`** (Control + aspas simples) ou pelo menu **Terminal -> New Terminal**.

---

## PASSO 3: Onde Construir Cada Parte (Mapa dos Cômodos)

- **Cômodo 1 (`01-acabamento-vitrine/index.html`) — Móveis e Fachada (Nível Fácil)**:
  Abra este arquivo no VS Code, procure por `[MOVEL 1]`, `[MOVEL 2]` e `[MOVEL 3]` para mudar o nome da sua loja, seu WhatsApp e seus produtos. Dê dois cliques no arquivo para ver sua loja funcionando no navegador!
- **Cômodo 2 (`02-alicerce-banco/models_esqueleto.py`) — Alicerce e Tijolos (Nível Mediano)**:
  Complete os blocos `# [TIJOLO 1]` e `# [TIJOLO 2]` para definir preço em centavos inteiros e separar Pedido de SubPedido.
- **Cômodo 3 (`03-paredes-api/api_esqueleto.py`) — Paredes e Segurança (Nível Mediano / Difícil)**:
  Complete os blocos `# [PAREDE 1]` e `# [PAREDE 2]` para impedir venda dupla de estoque e validar centavos no servidor.
- **Cômodo 4 (`04-telhado-deploy/`) — Telhado e Publicação R$ 0**:
  Já traz `.gitignore` protegendo seu `.env`, `requirements.txt` travado e `Procfile` para publicar grátis no GitHub, Vercel, Neon e Render!

---

## PASSO 4: Teste sua Construção no Terminal do VS Code!
No terminal aberto dentro do VS Code, digite:
```powershell
python testar_minha_casa.py
```
O inspetor automático vai dizer exatamente quais partes da sua casa já estão prontas e qual é o próximo tijolo!
